namespace QuizAmbiental;

public partial class QuizDificilPage : ContentPage
{
	public QuizDificilPage()
	{
		InitializeComponent();
	}
}