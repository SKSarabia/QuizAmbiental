namespace QuizAmbiental;

public partial class QuizMedioPage : ContentPage
{
	public QuizMedioPage()
	{
		InitializeComponent();
	}
}