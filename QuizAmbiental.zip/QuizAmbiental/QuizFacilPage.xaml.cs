namespace QuizAmbiental;

public partial class QuizFacilPage : ContentPage
{
	public QuizFacilPage()
	{
		InitializeComponent();
	}
}